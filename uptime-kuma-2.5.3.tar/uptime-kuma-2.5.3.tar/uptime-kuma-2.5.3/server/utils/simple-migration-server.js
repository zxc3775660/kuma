const express = require("express");
const http = require("node:http");
const { printServerUrls } = require("../util-server");

/**
 * SimpleMigrationServer
 * For displaying the migration status of the server
 * Also, it is used to let Docker healthcheck know the status of the server, as the main server is not started yet, healthcheck will think the server is down incorrectly.
 */
class SimpleMigrationServer {
    /**
     * Express app instance
     * @type {?Express}
     */
    app;

    /**
     * Server instance
     * @type {?Server}
     */
    server;

    /**
     * Response object
     * @type {?Response}
     */
    response;

    /**
     * Start the server
     * @param {number} port Port
     * @param {string} hostname Hostname
     * @returns {Promise<void>}
     */
    start(port, hostname) {
        this.app = express();
        this.server = http.createServer(this.app);

        this.app.get("/", (req, res) => {
            res.set("Content-Type", "text/html");

            // Don't use meta tag redirect, it may cause issues in Chrome (#6223)
            res.end(`
                <html lang="en">
                <head><title>Uptime Kuma Migration</title></head>
                <body>
                    Migration is in progress, it may take some time. You can check the progress in the console, or
                    <a href="/migrate-status" target="_blank">click here to check</a>.
                </body>
                </html>
            `);
        });

        this.app.get("/migrate-status", (req, res) => {
            res.set("Content-Type", "text/plain");
            res.write("Migration is in progress, listening message...\n");
            if (this.response) {
                this.response.write("Disconnected\n");
                this.response.end();
            }
            this.response = res;
            // never ending response
        });

        return new Promise((resolve) => {
            this.server.listen(port, hostname, () => {
                printServerUrls("migration", port, hostname);
                resolve();
            });
        });
    }

    /**
     * Update the message
     * @param {string} msg Message to update
     * @returns {void}
     */
    update(msg) {
        this.response?.write(msg + "\n");
    }

    /**
     * Stop the server
     * @returns {Promise<void>}
     */
    async stop() {
        this.response?.write("Finished, please refresh this page.\n");
        this.response?.end();
        await this.server?.close();
    }
}

module.exports = {
    SimpleMigrationServer,
};
